//
//  ModelBtn.h
//  GSFilterViewdemo
//
//  Created by ygkj on 16/12/2.
//  Copyright © 2016年 ygkj. All rights reserved.

#import <Foundation/Foundation.h>

@interface ModelBtn : NSObject

@property(nonatomic,strong) NSString *title;

@property(nonatomic,assign) NSInteger *tag;

@end
