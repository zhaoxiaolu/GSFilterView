//
//  DKFilterSectionHeaderView.h
//  Partner
//
//

#import <UIKit/UIKit.h>

@interface DKFilterSectionHeaderView : UIView

- (void)setSectionHeaderTitle:(NSString *)title;
@end
