# GSFilterView
###介绍
#####项目中用到的一个控件，由于开始设置的不是很完善，导致行高计算问题和规格信息显示不完整等bug，最近根据公司信息做了最新的更新，封装一下希望对需要的同学有所帮助。
#####一款封装好的商品加入购物车前规格选择的框架，自动计算规格的内容长度，自动计算行高，根据项目实际需要自动布局。
#####具体的使用方法有时间会在简书更新介绍欢迎关注，地址：http://www.jianshu.com/p/293ee1bfe104
#####喜欢的star一下，哈哈
 ![介绍图片1](https://github.com/zhangguosen3033/GSFilterView/blob/master/介绍图1.gif)
 ![介绍图片2](https://github.com/zhangguosen3033/GSFilterView/blob/master/介绍图2.gif)
